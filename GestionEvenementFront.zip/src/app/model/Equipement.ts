export class Equipement {
  public code: string;
  public nom: string;

  constructor() {}

}

export class Reservation {
  public code: string;
  public date: Date;

  constructor() {}

  // constructor(title: string, date: Date, isvalidated: boolean) {
  //   this.title = title;
  //   this.date = date;
  //   this.isvalidated = isvalidated;
  // }
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-espace-professeur',
  templateUrl: './espace-professeur.component.html',
  styleUrls: ['./espace-professeur.component.css']
})
export class EspaceProfesseurComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

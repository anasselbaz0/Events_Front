import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-espace-etudiant',
  templateUrl: './espace-etudiant.component.html',
  styleUrls: ['./espace-etudiant.component.css']
})
export class EspaceEtudiantComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
